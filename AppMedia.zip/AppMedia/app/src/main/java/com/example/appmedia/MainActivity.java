package com.example.appmedia;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
    EditText txtNome,txtN1,txtN2,txtN3,txtN4,txtP1,txtP2,txtP3,txtP4;
    Button btnCalcular;
    Float N1,N2,N3,N4,P1,P2,P3,P4,Final;
    String Nome;
    TextView txtResultado;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        txtNome = (EditText) findViewById(R.id.txtNome);
        btnCalcular = (Button) findViewById(R.id.button);

        txtN1 = (EditText) findViewById(R.id.txtN1);
        txtN2 = (EditText) findViewById(R.id.txtN2);
        txtN3 = (EditText) findViewById(R.id.txtN3);
        txtN4 = (EditText) findViewById(R.id.txtN4);
        txtP1 = (EditText) findViewById(R.id.txtP1);
        txtP2 = (EditText) findViewById(R.id.txtP2);
        txtP3 = (EditText) findViewById(R.id.txtP3);
        txtP4 = (EditText) findViewById(R.id.txtP4);
        txtResultado = findViewById(R.id.txtResultado);
        
        btnCalcular.setOnClickListener(new  View.OnClickListener() {
            @Override
            public void onClick(View view) {

                if (txtN1.getText().toString().equals("") || txtN2.getText().toString().equals("")
                        || txtN3.getText().toString().equals("") || txtN4.getText().toString().equals("")
                        || txtP1.getText().toString().equals("") || txtP2.getText().toString().equals("")
                        || txtP3.getText().toString().equals("") || txtP4.getText().toString().equals("")
                        || txtNome.getText().toString().equals("")
            ){
                    txtResultado.setText("Por favor insira Valores");
                }else{
                    N1 = Float.parseFloat(txtN1.getText().toString());
                    N2 = Float.parseFloat(txtN2.getText().toString());
                    N3 = Float.parseFloat(txtN3.getText().toString());
                    N4 = Float.parseFloat(txtN4.getText().toString());

                    P1 = Float.parseFloat(txtP1.getText().toString());
                    P2 = Float.parseFloat(txtP2.getText().toString());
                    P3 = Float.parseFloat(txtP3.getText().toString());
                    P4 = Float.parseFloat(txtP4.getText().toString());
                    Nome = txtNome.getText().toString();

                    Final = ((N1*P1)+(N2*P2)+(N3*P3)+(N4*P4))/(P1+P2+P3+P4);

                    if (Final>=6){
                        txtResultado.setText("O aluno " + Nome + " foi aprovado, com: " + Final);
                    } else if (Final < 6){
                        txtResultado.setText("O aluno " + Nome + " foi reprovado, com: " + Final);
                    }
                }
            }
        });
    }

}
